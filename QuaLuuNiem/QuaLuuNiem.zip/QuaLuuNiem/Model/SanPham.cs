﻿using System.ComponentModel.DataAnnotations.Schema;

namespace QuaLuuNiem.Model
{
    public class SanPham
    {
        
        public int ID {  get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaSP {  get; set; }
        public string TenSP {  get; set; }
        public string HinhAnh { get; set; }
        public int SoLuong {  get; set; }
        public int Gia {  get; set; }
        public string Loai {  get; set; }
        public string MoTa {  get; set; }
    }
}