﻿using System.ComponentModel.DataAnnotations.Schema;

namespace QuaLuuNiem.Model
{
    public class ThongTinKhachHang
    {
        public int ID { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaKH {  get; set; }
        public string HoTen {  get; set; }
        public string DiaChi {  get; set; }
        public string SDT {  get; set; }
        public string TenDangNhap {  get; set; }
        public string MatKhau {  get; set; }

    }
}
