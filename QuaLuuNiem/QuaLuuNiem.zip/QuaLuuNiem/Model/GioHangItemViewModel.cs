﻿namespace QuaLuuNiem.Model
{
    public class GioHangItemViewModel
    {
        public ThongTinGioHang GioHangItem { get; set; }
        public SanPham SanPham { get; set; }
    }
}
