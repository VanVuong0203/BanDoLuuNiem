﻿using System.ComponentModel.DataAnnotations.Schema;

namespace QuaLuuNiem.Model
{
    public class CTHD
    {
        public int ID { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaHD {  get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaSP {  get; set; }
        public string TenSP {  get; set; }
        public int SoLuong {  get; set; }
        public int Gia {  get; set; }
        public HoaDon HoaDon {  get; set; }
    }
}
