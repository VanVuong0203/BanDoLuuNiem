﻿using System.ComponentModel.DataAnnotations.Schema;

namespace QuaLuuNiem.Model
{
    public class HoaDon
    {
        public int ID { get; set; }
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public string MaHD {  get; set; }
        public string MaSP {  get; set; }
        public DateTime NgayBan {  get; set; }
        public int TongTien {  get; set; }

        public SanPham SanPham { get; set; }
    }
}
