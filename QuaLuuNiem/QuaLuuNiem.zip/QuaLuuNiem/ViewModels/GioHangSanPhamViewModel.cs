﻿using QuaLuuNiem.Model;

namespace QuaLuuNiem.ViewModels
{
    public class GioHangSanPhamViewModel
    {
        public ThongTinGioHang GioHangItem { get; set; }
        public SanPham SanPham { get; set; }
    }
}
