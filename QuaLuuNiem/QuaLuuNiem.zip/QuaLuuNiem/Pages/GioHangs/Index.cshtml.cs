﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using QuaLuuNiem.Data;
using QuaLuuNiem.Model;

namespace QuaLuuNiem.Pages.GioHangs
{
    public class IndexModel : PageModel
    {
        private readonly QuaLuuNiem.Data.QuaLuuNiemContext _context;

        public IndexModel(QuaLuuNiem.Data.QuaLuuNiemContext context)
        {
            _context = context;
        }

        public IList<ThongTinGioHang> ThongTinGioHang { get; set; } = default!;
        [BindProperty]
        public ThongTinGioHang Ttgh { get; set; } = default!;

        /*public async Task OnGetAsync()
        {
            ThongTinGioHang = await _context.GioHangs.ToListAsync();
        }*/

        public async Task OnGetAsync()
        {
            ThongTinGioHang = await _context.GioHangs.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var thongtingiohang = await _context.GioHangs.FindAsync(id);

            if (thongtingiohang != null)
            {
                _context.GioHangs.Remove(thongtingiohang);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
