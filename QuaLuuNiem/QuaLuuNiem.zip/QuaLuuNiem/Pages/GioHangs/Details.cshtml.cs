﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using QuaLuuNiem.Data;
using QuaLuuNiem.Model;

namespace QuaLuuNiem.Pages.GioHangs
{
    public class DetailsModel : PageModel
    {
        private readonly QuaLuuNiem.Data.QuaLuuNiemContext _context;

        public DetailsModel(QuaLuuNiem.Data.QuaLuuNiemContext context)
        {
            _context = context;
        }

        public List<ThongTinGioHang> SelectedItems { get; set; } = new List<ThongTinGioHang>();
        public decimal TotalPrice { get; set; }

        public async Task OnGetAsync(string selectedIds)
        {
            if (string.IsNullOrEmpty(selectedIds))
            {
                // No selected IDs
                return;
            }

            var ids = selectedIds.Split(',').Select(int.Parse).ToList();

            SelectedItems = await _context.GioHangs
                                          .Where(item => ids.Contains(item.ID))
                                          .ToListAsync();
            TotalPrice = SelectedItems.Sum(item => item.Gia * item.SoLuong);
        }
    }
}
