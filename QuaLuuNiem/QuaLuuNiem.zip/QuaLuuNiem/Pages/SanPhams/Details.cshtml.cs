﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Azure;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using QuaLuuNiem.Data;
using QuaLuuNiem.Model;

namespace QuaLuuNiem.Pages.SanPhams
{
    public class DetailsModel : PageModel
    {
        /*
        private readonly QuaLuuNiem.Data.QuaLuuNiemContext _context;

        public DetailsModel(QuaLuuNiem.Data.QuaLuuNiemContext context)
        {
            _context = context;
        }

        public SanPham SanPham { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sanpham = await _context.SanPham.FirstOrDefaultAsync(m => m.ID == id);
            if (sanpham == null)
            {
                return NotFound();
            }
            else
            {
                SanPham = sanpham;
            }
            return Page();
        }
        */
        //private readonly QuaLuuNiemContext _context; 
        private readonly QuaLuuNiem.Data.QuaLuuNiemContext _context;

        public DetailsModel(QuaLuuNiem.Data.QuaLuuNiemContext context)
        {
            _context = context;
        }

        public SanPham SanPham { get; set; } = default!;


        [BindProperty]
        public int ProductId { get; set; }

        public async Task<IActionResult> OnPostAsync()
        {
            // Lấy thông tin sản phẩm từ cơ sở dữ liệu
            var product = await _context.SanPham.FindAsync(ProductId);

            if (product != null)
            {
                // Tạo một đối tượng ThongTinGioHang mới
                var cartItem = new ThongTinGioHang
                {
                    MaKH = "KH1",
                    MaSP = product.MaSP,
                    TenSP = product.TenSP,
                    SoLuong = 1, // Số lượng ban đầu là 1, bạn có thể thay đổi nếu cần
                    Gia = product.Gia,
                    
                };

                // Thêm đối tượng ThongTinGioHang vào cơ sở dữ liệu
                _context.GioHangs.Add(cartItem);
                await _context.SaveChangesAsync();

                // Đặt thông báo thành công
                TempData["SuccessMessage"] = "Sản phẩm đã được thêm vào giỏ hàng thành công.";

                // Sau khi thêm vào giỏ hàng, chuyển hướng đến trang giỏ hàng
                return RedirectToPage("/Cart/Index");
            }

            // Đặt thông báo lỗi
            TempData["ErrorMessage"] = "Không thể thêm sản phẩm vào giỏ hàng.";

            // Trở lại trang chi tiết sản phẩm
            return RedirectToPage("/SanPhams/Details", new { id = ProductId });
        }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var sanpham = await _context.SanPham.FirstOrDefaultAsync(m => m.ID == id);
            if (sanpham == null)
            {
                return NotFound();
            }
            else
            {
                SanPham = sanpham;
            }
            return Page();
        }

        [HttpPost]
        public async Task<IActionResult> AddToCart(string productId, int quantity)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToPage("./Index");
            }

            var userId = "KH1"; // Thay thế bằng logic lấy ID người dùng thực tế

            var cartItem = await _context.GioHangs.FirstOrDefaultAsync(ci => ci.MaSP == productId && ci.MaKH == userId);

            if (cartItem == null)
            {
                // Sản phẩm chưa có trong giỏ hàng, thêm mới vào
                var product = await _context.SanPham.FindAsync(productId);
                if (product == null)
                {
                    return NotFound();
                }

                var newCartItem = new ThongTinGioHang
                {
                    MaSP = product.MaSP,
                    TenSP = product.TenSP,
                    Gia = product.Gia,
                    SoLuong = quantity,
                    HinhAnh = product.HinhAnh,
                    MaKH = userId
                };

                _context.GioHangs.Add(newCartItem);
            }
            else
            {
                // Sản phẩm đã có trong giỏ hàng, cộng thêm số lượng mới vào số lượng hiện có
                cartItem.SoLuong += quantity;
            }

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }

        [HttpPost]
        [HttpPost]
        public async Task<IActionResult> OnPostAddToCartAsync(int productId, int quantity)
        {
            if (!ModelState.IsValid)
            {
                return RedirectToPage("./Index");
            }

            var userId = "KH1"; // Thay thế bằng logic lấy ID người dùng thực tế

            var cartItem = await _context.GioHangs.SingleOrDefaultAsync(ci => ci.ID == productId && ci.MaKH == userId);

            if (cartItem == null)
            {
                // Sản phẩm chưa có trong giỏ hàng, thêm mới vào
                var product = await _context.SanPham.FindAsync(productId);
                if (product == null)
                {
                    return NotFound();
                }

                var newCartItem = new ThongTinGioHang
                {
                    MaSP = product.MaSP,
                    TenSP = product.TenSP,
                    Gia = product.Gia,
                    SoLuong = quantity,
                    HinhAnh = product.HinhAnh,
                    MaKH = userId
                };

                _context.GioHangs.Add(newCartItem);
            }
            else
            {
                // Sản phẩm đã có trong giỏ hàng, cộng thêm số lượng mới vào số lượng hiện có
                cartItem.SoLuong += quantity;
            }

            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }


    }
}
